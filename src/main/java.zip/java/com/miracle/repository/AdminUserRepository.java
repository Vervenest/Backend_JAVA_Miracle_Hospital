package com.miracle.repository;

import com.miracle.model.AdminUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminUserRepository extends JpaRepository<AdminUser, Integer> {
    Optional<AdminUser> findByAdminEmailAndAdminPasswordAndAdminStatus(String email, String password, String status);
}
